/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2018 NITK Surathkal
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Apoorva Bhargava <apoorvabhargava13@gmail.com>
 *          Mohit P. Tahiliani <tahiliani@nitk.edu.in>
 */

#include <iostream>
#include <string>
#include <fstream>
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/point-to-point-layout-module.h"
#include "ns3/applications-module.h"
#include "ns3/packet-sink.h"
#include "ns3/traffic-control-module.h"
#include "ns3/log.h"
#include "ns3/random-variable-stream.h"
#include "ns3/gtk-config-store.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/callback.h"
#include "ns3/vector.h"
#include "ns3/dce-module.h"

using namespace ns3;

std::vector<std::stringstream> filePlotQueue;
std::vector<std::stringstream> filePlotPacketSojourn;
Ptr<UniformRandomVariable> uv = CreateObject<UniformRandomVariable> ();
std::string dir;
double stopTime = 15;

void
CheckQueueSize (Ptr<QueueDisc> queue, uint32_t i)
{
  uint32_t qSize = queue->GetCurrentSize ().GetValue ();

  // check queue size every 1/100 of a second
  Simulator::Schedule (Seconds (0.001), &CheckQueueSize, queue, i);

  std::ofstream fPlotQueue (filePlotQueue [i].str ().c_str (), std::ios::out | std::ios::app);
  fPlotQueue << Simulator::Now ().GetSeconds () << " " << qSize << std::endl;
  fPlotQueue.close ();
}

void
CheckPacketSojourn (Ptr<QueueDisc> queue, uint32_t i)
{
  double qSize = queue->GetPacketSojournTime ().GetMilliSeconds ();

  // check queue size every 1/100 of a second
  Simulator::Schedule (Seconds (0.001), &CheckPacketSojourn, queue, i);

  std::ofstream fPlotQueue (filePlotPacketSojourn [i].str ().c_str (), std::ios::out | std::ios::app);
  fPlotQueue << Simulator::Now ().GetSeconds () << " " << qSize << std::endl;
  fPlotQueue.close ();
}

void InstallBulkSend (Ptr<Node> node, Ipv4Address address, uint16_t port, std::string sock_factory)
{
  BulkSendHelper source (sock_factory, InetSocketAddress (address, port));
  source.SetAttribute ("MaxBytes", UintegerValue (0));
  ApplicationContainer sourceApps = source.Install (node);
  Time timeToStart = Seconds (uv->GetValue (10, 11));
  sourceApps.Start (timeToStart);
  sourceApps.Stop (Seconds (stopTime));
}

void InstallPacketSink (Ptr<Node> node, uint16_t port, std::string sock_factory)
{
  PacketSinkHelper sink (sock_factory, InetSocketAddress (Ipv4Address::GetAny (), port));
  ApplicationContainer sinkApps = sink.Install (node);
  sinkApps.Start (Seconds (10.0));
  sinkApps.Stop (Seconds (stopTime));
}

static void
DropAtQueue (Ptr<OutputStreamWrapper> stream, Ptr<const QueueDiscItem> item)
{
  *stream->GetStream () << Simulator::Now ().GetSeconds () << " 1" << std::endl;
}

static void
MarkAtQueue (Ptr<OutputStreamWrapper> stream, Ptr<const QueueDiscItem> item, const char* reason)
{
  *stream->GetStream () << Simulator::Now ().GetSeconds () << " 1" << std::endl;
}

static void GetSSStats (Ptr<Node> node, Time at, std::string stack)
{
  if(stack == "linux")
  {
    DceApplicationHelper process;
    ApplicationContainer apps;
    process.SetBinary ("ss");
    process.SetStackSize (1 << 20);
    process.AddArgument ("-a");
    process.AddArgument ("-e");
    process.AddArgument ("-i");
    apps.Add(process.Install (node));
    apps.Start(at);
  }
}

int main (int argc, char *argv[])
{
  time_t rawtime;
  struct tm * timeinfo;
  char buffer[80];

  time (&rawtime);
  timeinfo = localtime (&rawtime);

  strftime (buffer,sizeof(buffer),"%d-%m-%Y-%I-%M-%S",timeinfo);
  std::string currentTime (buffer);

  uint32_t stream = 1;
  std::string stack = "linux";
  std::string sock_factory = "ns3::TcpSocketFactory";
  std::string transport_prot="TcpNewReno";
  std::string linux_prot="reno";
  std::string queue_disc_type = "FifoQueueDisc";
  bool useEcn = false;
  uint32_t dataSize = 1446;
  uint32_t delAckCount = 2;

  //Enable checksum if linux and ns3 node communicate 
  GlobalValue::Bind ("ChecksumEnabled", BooleanValue (true));

  CommandLine cmd;
  cmd.AddValue ("stream", "Seed value for random variable", stream);
  cmd.AddValue ("transport_prot", "Transport protocol to use: TcpNewReno, "
                "TcpHybla, TcpHighSpeed, TcpHtcp, TcpVegas, TcpScalable, TcpVeno, "
                "TcpBic, TcpYeah, TcpIllinois, TcpWestwood, TcpWestwoodPlus, TcpLedbat, "
                "TcpLp", transport_prot);
  cmd.AddValue ("linux_prot", "Linux network protocol to use: reno, "
                "hybla, highspeed, htcp, vegas, scalable, veno, "
                "bic, yeah, illinois, westwood, lp", linux_prot);
  cmd.AddValue ("queue_disc_type", "Queue disc type for gateway (e.g. ns3::CoDelQueueDisc)", queue_disc_type);
  cmd.AddValue ("useEcn", "Use ECN", useEcn);
  cmd.AddValue ("dataSize", "Data packet size", dataSize);
  cmd.AddValue ("delAckCount", "Delayed ack count", delAckCount);
  cmd.AddValue ("stopTime", "Stop time for applications / simulation time will be stopTime + 1", stopTime);
  cmd.AddValue ("stack", "Network stack: either ns3 or Linux", stack);
  cmd.Parse (argc, argv);

  uv->SetStream (stream);
  queue_disc_type = std::string ("ns3::") + queue_disc_type;
  if (stack=="ns3")
    {
      transport_prot = std::string ("ns3::") + transport_prot;
    }

  (stack=="ns3") ? (std::cout << transport_prot << std::endl) : (std::cout << linux_prot << std::endl);

  TypeId qdTid;
  NS_ABORT_MSG_UNLESS (TypeId::LookupByNameFailSafe (queue_disc_type, &qdTid), "TypeId " << queue_disc_type << " not found");

  if (stack=="ns3")
    {
      // Select TCP variant
      if (transport_prot.compare ("ns3::TcpWestwoodPlus") == 0)
        {
          // TcpWestwoodPlus is not an actual TypeId name; we need TcpWestwood here
          Config::SetDefault ("ns3::TcpL4Protocol::SocketType", TypeIdValue (TcpWestwood::GetTypeId ()));
          // the default protocol type in ns3::TcpWestwood is WESTWOOD
          Config::SetDefault ("ns3::TcpWestwood::ProtocolType", EnumValue (TcpWestwood::WESTWOODPLUS));
        }
      else
        {
          TypeId tcpTid;
          NS_ABORT_MSG_UNLESS (TypeId::LookupByNameFailSafe (transport_prot, &tcpTid), "TypeId " << transport_prot << " not found");
          Config::SetDefault ("ns3::TcpL4Protocol::SocketType", TypeIdValue (TypeId::LookupByName (transport_prot)));
        }

      Config::SetDefault ("ns3::TcpSocket::SndBufSize", UintegerValue (1 << 20));
      Config::SetDefault ("ns3::TcpSocket::RcvBufSize", UintegerValue (1 << 20));
      Config::SetDefault ("ns3::TcpSocket::InitialCwnd", UintegerValue (10));
      Config::SetDefault ("ns3::TcpSocket::DelAckCount", UintegerValue (delAckCount));
      Config::SetDefault ("ns3::TcpSocket::SegmentSize", UintegerValue (dataSize));
      Config::SetDefault ("ns3::TcpSocketBase::UseEcn", BooleanValue (useEcn));
    }
  
  Config::SetDefault ("ns3::PiQueueDisc::UseEcn", BooleanValue (useEcn));
  Config::SetDefault ("ns3::PiQueueDisc::QueueRef", DoubleValue (250));
  Config::SetDefault ("ns3::PiQueueDisc::MeanPktSize", UintegerValue (1500));
  Config::SetDefault ("ns3::RedQueueDisc::UseEcn", BooleanValue (useEcn));
  Config::SetDefault ("ns3::RedQueueDisc::ARED", BooleanValue (true));
  Config::SetDefault ("ns3::RedQueueDisc::Gentle", BooleanValue (true));
  Config::SetDefault ("ns3::RedQueueDisc::UseHardDrop", BooleanValue (false));
  Config::SetDefault ("ns3::RedQueueDisc::LinkBandwidth", DataRateValue (DataRate ("50Mbps")));
  Config::SetDefault ("ns3::RedQueueDisc::MeanPktSize", UintegerValue (1500));
  Config::SetDefault ("ns3::RedQueueDisc::LinkDelay", TimeValue (MilliSeconds (13.33)));

  NodeContainer m_switches;

  m_switches.Create (5);

  NodeContainer SA,RA,SB,RB,SC,RC,SD,RD,SE,RE,SF,RF;
  
  SA.Create (1);
  SB.Create (1);
  SC.Create (1);
  SD.Create (1);
  SE.Create (1);
  SF.Create (1);

  RA.Create (1);
  RB.Create (1);
  RC.Create (1);
  RD.Create (1);
  RE.Create (1);
  RF.Create (1);

  NodeContainer senderNodes, receiverNodes;
  senderNodes.Add (SA);
  senderNodes.Add (SB);
  senderNodes.Add (SC);
  senderNodes.Add (SD);
  senderNodes.Add (SE);
  senderNodes.Add (SF);
  receiverNodes.Add (RA);
  receiverNodes.Add (RB);
  receiverNodes.Add (RC);
  receiverNodes.Add (RD);
  receiverNodes.Add (RE);
  receiverNodes.Add (RF);

  std::vector <PointToPointHelper> trunkLink;

  // Create the point-to-point link helpers
  PointToPointHelper pointToPointRouter;
  pointToPointRouter.SetDeviceAttribute  ("DataRate", StringValue ("50Mbps"));
  pointToPointRouter.SetChannelAttribute ("Delay", StringValue ("0.25ms"));
  trunkLink.push_back (pointToPointRouter);
  pointToPointRouter.SetDeviceAttribute  ("DataRate", StringValue ("150Mbps"));
  pointToPointRouter.SetChannelAttribute ("Delay", StringValue ("0.25ms"));
  trunkLink.push_back (pointToPointRouter);
  pointToPointRouter.SetDeviceAttribute  ("DataRate", StringValue ("150Mbps"));
  pointToPointRouter.SetChannelAttribute ("Delay", StringValue ("0.25ms"));
  trunkLink.push_back (pointToPointRouter);
  pointToPointRouter.SetDeviceAttribute  ("DataRate", StringValue ("100Mbps"));
  pointToPointRouter.SetChannelAttribute ("Delay", StringValue ("0.25ms"));
  trunkLink.push_back (pointToPointRouter);

  PointToPointHelper pointToPointLeaf;
  pointToPointLeaf.SetDeviceAttribute    ("DataRate", StringValue ("150Mbps"));
  pointToPointLeaf.SetChannelAttribute   ("Delay", StringValue ("0.001ms"));

  std::vector<NetDeviceContainer> m_switchDevices;
  for (uint32_t i = 0; i < m_switches.GetN () - 1; ++i)
    {
      NetDeviceContainer c = trunkLink [i].Install (m_switches.Get (i), m_switches.Get (i + 1));
      m_switchDevices.push_back (c);
    }

  NetDeviceContainer SASwitch1Dev, SBSwitch2Dev, SCSwitch3Dev, SDSwitch1Dev, SESwitch4Dev, SFSwitch2Dev, RASwitch4Dev, RBSwitch5Dev, RCSwitch4Dev, RDSwitch2Dev, RESwitch5Dev, RFSwitch3Dev;

  std::vector <NetDeviceContainer> m_senderNodesDevices;
  SASwitch1Dev = pointToPointLeaf.Install (SA.Get (0), m_switches.Get (0));
  m_senderNodesDevices.push_back (SASwitch1Dev);
  SDSwitch1Dev = pointToPointLeaf.Install (SD.Get (0), m_switches.Get (0));
  m_senderNodesDevices.push_back (SDSwitch1Dev);
  SBSwitch2Dev = pointToPointLeaf.Install (SB.Get (0), m_switches.Get (1));
  m_senderNodesDevices.push_back (SBSwitch2Dev);
  SFSwitch2Dev = pointToPointLeaf.Install (SF.Get (0), m_switches.Get (1));
  m_senderNodesDevices.push_back (SFSwitch2Dev);
  SCSwitch3Dev = pointToPointLeaf.Install (SC.Get (0), m_switches.Get (2));
  m_senderNodesDevices.push_back (SCSwitch3Dev);
  SESwitch4Dev = pointToPointLeaf.Install (SE.Get (0), m_switches.Get (3));
  m_senderNodesDevices.push_back (SESwitch4Dev);

  std::vector <NetDeviceContainer> m_receiverNodesDevices;
  RDSwitch2Dev = pointToPointLeaf.Install (RD.Get (0), m_switches.Get (1));
  m_receiverNodesDevices.push_back (RDSwitch2Dev);
  RFSwitch3Dev = pointToPointLeaf.Install (RF.Get (0), m_switches.Get (2));
  m_receiverNodesDevices.push_back (RFSwitch3Dev);
  RASwitch4Dev = pointToPointLeaf.Install (RA.Get (0), m_switches.Get (3));
  m_receiverNodesDevices.push_back (RASwitch4Dev);
  RCSwitch4Dev = pointToPointLeaf.Install (RC.Get (0), m_switches.Get (3));
  m_receiverNodesDevices.push_back (RCSwitch4Dev);
  RBSwitch5Dev = pointToPointLeaf.Install (RB.Get (0), m_switches.Get (4));
  m_receiverNodesDevices.push_back (RBSwitch5Dev);
  RESwitch5Dev = pointToPointLeaf.Install (RE.Get (0), m_switches.Get (4));
  m_receiverNodesDevices.push_back (RESwitch5Dev);

  DceManagerHelper dceManager;
  LinuxStackHelper linuxStack;
  InternetStackHelper internetStack;

  if (stack=="linux")
    {
      sock_factory = "ns3::LinuxTcpSocketFactory";
      dceManager.SetTaskManagerAttribute ("FiberManagerType", StringValue ("UcontextFiberManager"));
      dceManager.SetNetworkStack ("ns3::LinuxSocketFdFactory", "Library", StringValue ("liblinux.so"));
      linuxStack.Install (senderNodes);
      linuxStack.Install (receiverNodes);
      internetStack.Install (m_switches);
    }
  else if (stack=="ns3")
    {
      internetStack.InstallAll (); 
    }

  //Assign IP address. We keep each sender-switch link in a different network
  std::vector <Ipv4InterfaceContainer> m_switchInterfaces;
  std::vector <Ipv4InterfaceContainer> m_senderIpv4Interfaces;
  std::vector <Ipv4InterfaceContainer> m_receiverIpv4Interfaces;

  Ipv4AddressHelper ipAddresses ("10.0.0.0", "255.255.255.0");
  for (uint32_t i = 0; i < m_switchDevices.size (); ++i)
    {
      NetDeviceContainer ndc;
      ndc.Add (m_switchDevices [i].Get (0));
      ndc.Add (m_switchDevices [i].Get (1));
      Ipv4InterfaceContainer ifc = ipAddresses.Assign (ndc);
      m_switchInterfaces.push_back (ifc);
      ipAddresses.NewNetwork ();
    }

  for (uint32_t i = 0; i < m_senderNodesDevices.size (); ++i)
    {
      NetDeviceContainer ndc;
      ndc.Add (m_senderNodesDevices [i].Get (0));
      ndc.Add (m_senderNodesDevices [i].Get (1));
      Ipv4InterfaceContainer ifc = ipAddresses.Assign (ndc);
      m_senderIpv4Interfaces.push_back (ifc);
      ipAddresses.NewNetwork ();
    }

  for (uint32_t i = 0; i < m_receiverNodesDevices.size (); ++i)
    {
      NetDeviceContainer ndc;
      ndc.Add (m_receiverNodesDevices [i].Get (0));
      ndc.Add (m_receiverNodesDevices [i].Get (1));
      Ipv4InterfaceContainer ifc = ipAddresses.Assign (ndc);
      m_receiverIpv4Interfaces.push_back (ifc);
      ipAddresses.NewNetwork ();
    }

  if (stack=="linux")
    {
      dceManager.Install (senderNodes);
      dceManager.Install (receiverNodes);
      dceManager.Install (m_switches);
      linuxStack.SysctlSet (senderNodes, ".net.ipv4.conf.default.forwarding", "1");
      linuxStack.SysctlSet (receiverNodes, ".net.ipv4.conf.default.forwarding", "1");
      linuxStack.SysctlSet (senderNodes, ".net.ipv4.tcp_congestion_control", linux_prot);
      linuxStack.SysctlSet (receiverNodes, ".net.ipv4.tcp_congestion_control", linux_prot);
      linuxStack.SysctlSet (senderNodes, ".net.ipv4.tcp_ecn", "1");
      linuxStack.SysctlSet (receiverNodes, ".net.ipv4.tcp_ecn", "1");
    }
    
  if (stack=="linux")
    {
      std::ostringstream serverIp;
      //Ptr<Ipv4> routeraddress = m_switches.Get (0)->GetObject<Ipv4> ();
      //Ipv4Address serverAddress = routeraddress->GetAddress (2, 0).GetLocal ();
      Ipv4Address serverAddress = m_receiverIpv4Interfaces [2].GetAddress (0, 0);
      serverAddress.Print (serverIp);
      std::cout << "Ip Address:" << serverIp.str() << std::endl;

      /*std::ostringstream serverIp1;
      Ptr<Ipv4> routeraddress1 = senderNodes.Get (0)->GetObject<Ipv4> ();
      Ipv4Address serverAddress1 = routeraddress1->GetAddress (0, 0).GetLocal ();
      //Ipv4Address serverAddress = m_senderIpv4Interfaces [0].GetAddress (0, 0);
      serverAddress1.Print (serverIp1);
      std::cout << "Ip Address:" << serverIp1.str() << std::endl;*/

      //Static Routing
      Ptr<Ipv4> ipv4Switch1 = m_switches.Get (0)->GetObject<Ipv4> ();
      Ptr<Ipv4> ipv4Switch2 = m_switches.Get (1)->GetObject<Ipv4> ();
      Ptr<Ipv4> ipv4Switch3 = m_switches.Get (2)->GetObject<Ipv4> ();
      Ptr<Ipv4> ipv4Switch4 = m_switches.Get (3)->GetObject<Ipv4> ();
      Ptr<Ipv4> ipv4Switch5 = m_switches.Get (4)->GetObject<Ipv4> ();

      Ipv4StaticRoutingHelper routingHelper;

      Ptr<Ipv4StaticRouting> staticRoutingSwitch1 = routingHelper.GetStaticRouting (ipv4Switch1);
      Ptr<Ipv4StaticRouting> staticRoutingSwitch2 = routingHelper.GetStaticRouting (ipv4Switch2);
      Ptr<Ipv4StaticRouting> staticRoutingSwitch3 = routingHelper.GetStaticRouting (ipv4Switch3);
      Ptr<Ipv4StaticRouting> staticRoutingSwitch4 = routingHelper.GetStaticRouting (ipv4Switch4);
      Ptr<Ipv4StaticRouting> staticRoutingSwitch5 = routingHelper.GetStaticRouting (ipv4Switch5);

      //Static Routing of Switch 1
      //Flow A
      staticRoutingSwitch1->AddNetworkRouteTo (Ipv4Address ("10.0.12.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.0.2"), 1);
      //Flow D
      staticRoutingSwitch1->AddNetworkRouteTo (Ipv4Address ("10.0.10.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.0.2"), 1);

      //Static Routing of Switch 2
      //Flow A
      staticRoutingSwitch2->AddNetworkRouteTo (Ipv4Address ("10.0.4.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.0.1"), 1);
      staticRoutingSwitch2->AddNetworkRouteTo (Ipv4Address ("10.0.12.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.1.2"), 2);
      //Flow D
      staticRoutingSwitch2->AddNetworkRouteTo (Ipv4Address ("10.0.5.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.0.1"), 1);
      //Flow B
      staticRoutingSwitch2->AddNetworkRouteTo (Ipv4Address ("10.0.14.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.1.2"), 2);
      //Flow F
      staticRoutingSwitch2->AddNetworkRouteTo (Ipv4Address ("10.0.11.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.1.2"), 2);

      //Static Routing of Switch 3
      //Flow A
      staticRoutingSwitch3->AddNetworkRouteTo (Ipv4Address ("10.0.4.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.1.1"), 1);
      staticRoutingSwitch3->AddNetworkRouteTo (Ipv4Address ("10.0.12.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.2"), 2);
      //Flow B
      staticRoutingSwitch3->AddNetworkRouteTo (Ipv4Address ("10.0.6.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.1.1"), 1);
      staticRoutingSwitch3->AddNetworkRouteTo (Ipv4Address ("10.0.14.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.2"), 2);
      //Flow C
      staticRoutingSwitch3->AddNetworkRouteTo (Ipv4Address ("10.0.13.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.2"), 2);
      //Flow F
      staticRoutingSwitch3->AddNetworkRouteTo (Ipv4Address ("10.0.7.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.1.1"), 1);
      
      //Static Routing of Switch 4
      //Flow A
      staticRoutingSwitch4->AddNetworkRouteTo (Ipv4Address ("10.0.4.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.1"), 1);
      //Flow B
      staticRoutingSwitch4->AddNetworkRouteTo (Ipv4Address ("10.0.6.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.1"), 1);
      staticRoutingSwitch4->AddNetworkRouteTo (Ipv4Address ("10.0.14.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.3.2"), 2);
      //Flow C
      staticRoutingSwitch4->AddNetworkRouteTo (Ipv4Address ("10.0.8.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.1"), 1);
      //Flow E
      staticRoutingSwitch4->AddNetworkRouteTo (Ipv4Address ("10.0.15.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.3.2"), 2);

      //Static Routing of Switch 5
      //Flow B
      staticRoutingSwitch5->AddNetworkRouteTo (Ipv4Address ("10.0.6.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.3.1"), 1);
      //Flow E
      staticRoutingSwitch5->AddNetworkRouteTo (Ipv4Address ("10.0.9.0"), Ipv4Mask ("255.255.255.0"), Ipv4Address ("10.0.2.1"), 1);

      std::ostringstream cmd_oss;

      //Default route for sender A
      LinuxStackHelper::RunIp (senderNodes.Get (0), Seconds (0.00001), "route add default via 10.0.4.2 dev sim0");
      LinuxStackHelper::RunIp (senderNodes.Get (0), Seconds (0.00001), "link set sim0 up");

      //Default route for sender B
      LinuxStackHelper::RunIp (senderNodes.Get (1), Seconds (0.00001), "route add default via 10.0.6.2 dev sim0");
      LinuxStackHelper::RunIp (senderNodes.Get (1), Seconds (0.00001), "link set sim0 up");

      //Default route for sender C
      LinuxStackHelper::RunIp (senderNodes.Get (2), Seconds (0.00001), "route add default via 10.0.8.2 dev sim0");
      LinuxStackHelper::RunIp (senderNodes.Get (2), Seconds (0.00001), "link set sim0 up");

      //Default route for sender D
      LinuxStackHelper::RunIp (senderNodes.Get (3), Seconds (0.00001), "route add default via 10.0.5.2 dev sim0");
      LinuxStackHelper::RunIp (senderNodes.Get (3), Seconds (0.00001), "link set sim0 up");

      //Default route for sender E
      LinuxStackHelper::RunIp (senderNodes.Get (4), Seconds (0.00001), "route add default via 10.0.9.2 dev sim0");
      LinuxStackHelper::RunIp (senderNodes.Get (4), Seconds (0.00001), "link set sim0 up");

      //Default route for sender F
      LinuxStackHelper::RunIp (senderNodes.Get (5), Seconds (0.00001), "route add default via 10.0.7.2 dev sim0");
      LinuxStackHelper::RunIp (senderNodes.Get (5), Seconds (0.00001), "link set sim0 up");

      //Default route for receiver A
      LinuxStackHelper::RunIp (receiverNodes.Get (0), Seconds (0.00001), "route add default via 10.0.12.2 dev sim0");
      LinuxStackHelper::RunIp (receiverNodes.Get (0), Seconds (0.00001), "link set sim0 up");

      //Default route for receiver B
      LinuxStackHelper::RunIp (receiverNodes.Get (1), Seconds (0.00001), "route add default via 10.0.14.2 dev sim0");
      LinuxStackHelper::RunIp (receiverNodes.Get (1), Seconds (0.00001), "link set sim0 up");

      //Default route for receiver C
      LinuxStackHelper::RunIp (receiverNodes.Get (2), Seconds (0.00001), "route add default via 10.0.13.2 dev sim0");
      LinuxStackHelper::RunIp (receiverNodes.Get (2), Seconds (0.00001), "link set sim0 up");

      //Default route for receiver D
      LinuxStackHelper::RunIp (receiverNodes.Get (3), Seconds (0.00001), "route add default via 10.0.10.2 dev sim0");
      LinuxStackHelper::RunIp (receiverNodes.Get (3), Seconds (0.00001), "link set sim0 up");

      //Default route for receiver E
      LinuxStackHelper::RunIp (receiverNodes.Get (4), Seconds (0.00001), "route add default via 10.0.15.2 dev sim0");
      LinuxStackHelper::RunIp (receiverNodes.Get (4), Seconds (0.00001), "link set sim0 up");

      //Default route for receiver F
      LinuxStackHelper::RunIp (receiverNodes.Get (5), Seconds (0.00001), "route add default via 10.0.11.2 dev sim0");
      LinuxStackHelper::RunIp (receiverNodes.Get (5), Seconds (0.00001), "link set sim0 up");
    }
    else if (stack=="ns3")
      {
        std::ostringstream serverIp;
        //Ptr<Ipv4> routeraddress = RE.Get (0)->GetObject<Ipv4> ();
        Ipv4Address serverAddress = m_senderIpv4Interfaces [0].GetAddress (0, 0);
        serverAddress.Print (serverIp);
        std::cout << "Ip Address:" << serverIp.str() << std::endl;
        
        Ipv4GlobalRoutingHelper::PopulateRoutingTables ();
      }

  dir = "gfc1-results/" + currentTime + "/";
  std::string dirToSave = "mkdir -p " + dir;
  system (dirToSave.c_str ());
  system ((dirToSave + "/pcap/").c_str ());
  system ((dirToSave + "/queueTraces/").c_str ());
  system (("cp -R PlotScripts-1/* " + dir + "/pcap/").c_str ());

  TrafficControlHelper tch;
  tch.SetRootQueueDisc (queue_disc_type);

  QueueDiscContainer qd;
  AsciiTraceHelper asciiTraceHelper;
  Ptr<OutputStreamWrapper> streamWrapper;
  uint8_t x = 0;
  for (uint32_t i = 0; i < m_switches.GetN () - 1; i++)
    {
      tch.Uninstall (m_switches.Get (i)->GetDevice (x));
      qd.Add (tch.Install (m_switches.Get (i)->GetDevice (x)).Get (0));
      streamWrapper = asciiTraceHelper.CreateFileStream (dir + "/queueTraces/drop-" + std::to_string (i) + ".plotme");
      qd.Get (i)->TraceConnectWithoutContext ("Drop", MakeBoundCallback (&DropAtQueue, streamWrapper));
      streamWrapper = asciiTraceHelper.CreateFileStream (dir + "/queueTraces/mark-" + std::to_string (i) + ".plotme");
      qd.Get (i)->TraceConnectWithoutContext ("Mark", MakeBoundCallback (&MarkAtQueue, streamWrapper));
      filePlotQueue.push_back (std::stringstream (dir + "/queue-" + std::to_string (i) + ".plotme"));
      remove (filePlotQueue [i].str ().c_str ());
      filePlotPacketSojourn.push_back (std::stringstream (dir + "/delay-" + std::to_string (i) + ".plotme"));
      remove (filePlotPacketSojourn [i].str ().c_str ());
      Simulator::ScheduleNow (&CheckQueueSize, qd.Get (i), i);
      Simulator::ScheduleNow (&CheckPacketSojourn, qd.Get (i), i);
      x = 1;
    }

  Config::Set ("/$ns3::NodeListPriv/NodeList/0/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/0/$" + queue_disc_type + "/MaxSize", QueueSizeValue (QueueSize ("38p")));
  Config::Set ("/$ns3::NodeListPriv/NodeList/1/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$" + queue_disc_type + "/MaxSize", QueueSizeValue (QueueSize ("38p")));
  Config::Set ("/$ns3::NodeListPriv/NodeList/2/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$" + queue_disc_type + "/MaxSize", QueueSizeValue (QueueSize ("38p")));
  Config::Set ("/$ns3::NodeListPriv/NodeList/3/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$" + queue_disc_type + "/MaxSize", QueueSizeValue (QueueSize ("38p")));

  Config::Set ("/$ns3::NodeListPriv/NodeList/0/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/0/$ns3::PiQueueDisc/QueueRef", DoubleValue (10));
  Config::Set ("/$ns3::NodeListPriv/NodeList/1/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/QueueRef", DoubleValue (10));
  Config::Set ("/$ns3::NodeListPriv/NodeList/2/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/QueueRef", DoubleValue (10));
  Config::Set ("/$ns3::NodeListPriv/NodeList/3/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/QueueRef", DoubleValue (10));

  Config::Set ("/$ns3::NodeListPriv/NodeList/0/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/0/$ns3::PiQueueDisc/A", DoubleValue ( 0.009816311056));
  Config::Set ("/$ns3::NodeListPriv/NodeList/1/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/A", DoubleValue (0.002013602268));
  Config::Set ("/$ns3::NodeListPriv/NodeList/2/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/A", DoubleValue (0.002013602268));
  Config::Set ("/$ns3::NodeListPriv/NodeList/3/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/A", DoubleValue (0.004908155528));

  Config::Set ("/$ns3::NodeListPriv/NodeList/0/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/0/$ns3::PiQueueDisc/B", DoubleValue (0.005285705953));
  Config::Set ("/$ns3::NodeListPriv/NodeList/1/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/B", DoubleValue (0.001342401512));
  Config::Set ("/$ns3::NodeListPriv/NodeList/2/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/B", DoubleValue (0.001342401512));
  Config::Set ("/$ns3::NodeListPriv/NodeList/3/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/B", DoubleValue (0.002642852977));

  Config::Set ("/$ns3::NodeListPriv/NodeList/0/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/0/$ns3::PiQueueDisc/W", DoubleValue (400));
  Config::Set ("/$ns3::NodeListPriv/NodeList/1/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/W", DoubleValue (400));
  Config::Set ("/$ns3::NodeListPriv/NodeList/2/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/W", DoubleValue (400));
  Config::Set ("/$ns3::NodeListPriv/NodeList/3/$ns3::Node/$ns3::TrafficControlLayer/RootQueueDiscList/1/$ns3::PiQueueDisc/W", DoubleValue (400));

  uint16_t port = 50000;

  //A Sink Applications
  for (uint16_t i = 0; i < 3; i++)
    {
      InstallPacketSink (receiverNodes.Get (0), port + i, sock_factory);
    }

  //B Sink Applications
  for (uint16_t i = 0; i < 3; i++)
    {
      InstallPacketSink (receiverNodes.Get (1), port + i, sock_factory);
    }

  //C Sink Applications
  for (uint16_t i = 0; i < 3; i++)
    {
      InstallPacketSink (receiverNodes.Get (2), port + i, sock_factory);
    }

  //D Sink Applications
  for (uint16_t i = 0; i < 6; i++)
    {
      InstallPacketSink (receiverNodes.Get (3), port + i, sock_factory);
    }

  //E Sink Applications
  for (uint16_t i = 0; i < 6; i++)
    {
      InstallPacketSink (receiverNodes.Get (4), port + i, sock_factory);
    }

  //F Sink Applications
  for (uint16_t i = 0; i < 2; i++)
    {
      InstallPacketSink (receiverNodes.Get (5), port + i, sock_factory);
    } 

  
  //A Bulk Send Application
  for (uint16_t i = 0; i < 3; i++)
    {
      InstallBulkSend (senderNodes.Get (0), m_receiverIpv4Interfaces [2].GetAddress (0, 0), port + i, sock_factory);
    }

  //B Bulk Send Application
  for (uint16_t i = 0; i < 3; i++)
    {
      InstallBulkSend (senderNodes.Get (1), m_receiverIpv4Interfaces [4].GetAddress (0, 0), port + i, sock_factory);
    }

  //C Bulk Send Application
  for (uint16_t i = 0; i < 3; i++)
    {
      InstallBulkSend (senderNodes.Get (2), m_receiverIpv4Interfaces [3].GetAddress (0, 0), port + i, sock_factory);
    }

  //D Bulk Send Application
  for (uint16_t i = 0; i < 6; i++)
    {
      InstallBulkSend (senderNodes.Get (3), m_receiverIpv4Interfaces [0].GetAddress (0, 0), port + i, sock_factory);
    }

  //E Bulk Send Application
  for (uint16_t i = 0; i < 6; i++)
    {
      InstallBulkSend (senderNodes.Get (4), m_receiverIpv4Interfaces [5].GetAddress (0, 0), port + i, sock_factory);
    }

  //F Bulk Send Application
  for (uint16_t i = 0; i < 2; i++)
    {
      InstallBulkSend (senderNodes.Get (5), m_receiverIpv4Interfaces [1].GetAddress (0, 0), port + i, sock_factory);
    }

  pointToPointRouter.EnablePcapAll (dir + "/pcap/N", true);

  if (stack=="linux")
    {
      for (int j=0; j<senderNodes.GetN (); j++)
       {
          for(float i = 10.0; i <= stopTime ; i=i+0.1)
            {
               GetSSStats(senderNodes.Get (j), Seconds(i), stack);
            }
       }
    }
  

  std::ofstream myfile;
  myfile.open (dir + "config.txt", std::fstream::in | std::fstream::out | std::fstream::app);
  myfile << "useEcn " << useEcn << "\n";
  myfile << "queue_disc_type " << queue_disc_type << "\n";
  myfile << "stream  " << stream << "\n";
  myfile << "transport_prot " << transport_prot << "\n";
  myfile << "dataSize " << dataSize << "\n";
  myfile << "delAckCount " << delAckCount << "\n";
  myfile.close ();

  Simulator::Stop (Seconds (stopTime));
  Simulator::Run ();

  myfile.open (dir + "queueStats.txt", std::fstream::in | std::fstream::out | std::fstream::app);
  for (uint32_t i = 0; i < qd.GetN (); i++)
    {
      myfile << std::endl;
      myfile << "Stat for " << i + 1 << " Queue";
      myfile << qd.Get (i)->GetStats ();
    }
  myfile.close ();

  Simulator::Destroy ();
  return 0;
} 

