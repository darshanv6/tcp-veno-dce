import os
import sys
import numpy as np

#start_time = int (sys.argv[1])
#end_time = int (sys.argv[2])
#interval = float (sys.argv[3])

def get_sockets(in_filepath):
  all_sockets = []
  curr_socket = []
  first_socket = 1
  with open(in_filepath) as in_file:
    for line in in_file:
      if "ss -a -e -i" in line:
        if first_socket:
          first_socket = 0
        else:
          all_sockets.append(curr_socket)
          curr_socket = []
      else:
        if not first_socket:
          curr_socket.append(line)
		
  all_sockets.append(curr_socket)
  return all_sockets

sender_node_id = range (5, 11)
receiver_node_id = range (11, 17)

if (not os.path.isdir("../gfc1-results/cwnd_data")):
  os.system("mkdir ../gfc1-results/cwnd_data")

for i in sender_node_id:
  os.system ("cat ../files-"+str(i)+"/var/log/*/* > "+"../gfc1-results/cwnd_data/"+str(i))

#cwnd_data_1 = []
#cwnd_data_2 = []
#cwnd_data_3 = []

for i in sender_node_id:
  #f1=open("../gfc1-results/cwnd_data/"+str(i)+"_50000_format.txt","w+")
  #f2=open("../gfc1-results/cwnd_data/"+str(i)+"_50001_format.txt","w+")
  #f3=open("../gfc1-results/cwnd_data/"+str(i)+"_50002_format.txt","w+")
  #with open ("../gfc1-results/cwnd_data/"+str(i))
  #in_filepath = open("../gfc1-results/cwnd_data/"+str(i), "rt")
  in_filepath = "../gfc1-results/cwnd_data/"+str(i)
  all_sockets = get_sockets(in_filepath)
  write_mode = 'w'
  for socket in all_sockets:
    time_found = 0
    cwnd_found = 0
    port_found = 0
    time = None
    cwnd = None
    for info in socket:
      if "NS3" in info:
        time = info.split("NS3 Time:")[1].split(',')[0].strip().split('(')[1].strip().strip(')').strip().strip('+').strip('ns')
        time_found = 1
      if ":50000" in info:
        port = 50000
        port_found = 1
			
      elif ":50001" in info:
        port = 50001
        port_found = 1

      elif ":50002" in info:
        port = 50002
        port_found = 1

      elif ":50003" in info:
        port = 50003
        port_found = 1

      elif ":50004" in info:
        port = 50004
        port_found = 1

      elif ":50005" in info:
        port = 50005
        port_found = 1
			
      if "cwnd" in info:
        cwnd = info.split("cwnd:")[1].split()[0]
        if port_found:
          with open("../gfc1-results/cwnd_data/"+str(i) + "_" + str(port) + "_format.txt", write_mode) as out_file:
            out_file.write(str(time) + "," + str(cwnd) + "\n")
          write_mode = 'a'
          port_found = 0
  
